CUDA_VISIBLE_DEVICES=1 NCCL_P2P_LEVEL=NVL python ./RGBE_workspace/test_rgbe_mgpus.py --script_name patrack --dataset_name VisEvent --yaml_name rgbe --epoch 60
